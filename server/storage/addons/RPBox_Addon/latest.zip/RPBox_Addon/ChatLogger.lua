-- RPBox ChatLogger
-- 聊天记录采集模块

RPBox.ChatLogger = {}
local ChatLogger = RPBox.ChatLogger

-- 监听的聊天频道
local CHAT_EVENTS = {
    "CHAT_MSG_SAY",
    "CHAT_MSG_YELL",
    "CHAT_MSG_EMOTE",
    "CHAT_MSG_TEXT_EMOTE",
    "CHAT_MSG_PARTY",
    "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID",
    "CHAT_MSG_RAID_LEADER",
}

-- 记录上限
local MAX_RECORDS = 10000
local WARN_THRESHOLD = 9000

-- 自动白名单计时器
local targetTimer = nil

-- 初始化
function ChatLogger:Init()
    -- 注册聊天事件
    for _, event in ipairs(CHAT_EVENTS) do
        ChatFrame_AddMessageEventFilter(event, function(_, _, msg, sender, ...)
            self:OnChatMessage(event, msg, sender)
            return false
        end)
    end

    -- 监听目标变化（自动白名单）
    local frame = CreateFrame("Frame")
    frame:RegisterEvent("PLAYER_TARGET_CHANGED")
    frame:SetScript("OnEvent", function()
        self:OnTargetChanged()
    end)

    print("|cFF00FF00[RPBox]|r 聊天记录模块已启动")
end

-- 处理聊天消息
function ChatLogger:OnChatMessage(event, msg, sender)
    local unitID = sender
    local isFromSelf = (unitID == UnitName("player") .. "-" .. GetRealmName())

    -- 检查是否应该记录
    if not self:ShouldRecord(unitID, isFromSelf) then
        return
    end

    -- 获取TRP3信息
    local trp3Info = self:GetTRP3Info(unitID)

    -- 保存记录
    self:SaveRecord({
        timestamp = time(),
        channel = event,
        sender = {
            gameID = unitID,
            trp3 = trp3Info,
        },
        content = msg,
    })
end

-- 判断是否应该记录
function ChatLogger:ShouldRecord(unitID, isFromSelf)
    -- 自己的消息总是记录
    if isFromSelf then return true end

    -- 黑名单检查
    if self:IsBlacklisted(unitID) then return false end

    -- 有TRP3信息则记录
    if self:GetTRP3Info(unitID) then return true end

    -- 白名单检查
    if RPBox_Config.whitelist[unitID] then return true end

    return false
end

-- 检查是否在黑名单
function ChatLogger:IsBlacklisted(unitID)
    -- RPBox黑名单
    if RPBox_Config.blacklist[unitID] then return true end

    -- WoW原生拉黑
    if C_FriendList and C_FriendList.IsIgnored then
        local name = unitID:match("^([^-]+)")
        if C_FriendList.IsIgnored(name) then return true end
    end

    -- TRP3拉黑检查
    if TRP3_API and TRP3_API.register and TRP3_API.register.isIDIgnored then
        if TRP3_API.register.isIDIgnored(unitID) then return true end
    end

    return false
end

-- 获取TRP3角色信息
function ChatLogger:GetTRP3Info(unitID)
    if not TRP3_API or not TRP3_API.register then
        return nil
    end

    -- 获取角色绑定的profileID
    local character = TRP3_API.register.getUnitIDCharacter(unitID)
    if not character or not character.profileID then
        return nil
    end

    -- 获取profile数据
    local profile = TRP3_API.register.getProfile(character.profileID)
    if not profile or not profile.player or not profile.player.characteristics then
        return nil
    end

    local chars = profile.player.characteristics
    return {
        FN = chars.FN,  -- 名
        LN = chars.LN,  -- 姓
        TI = chars.TI,  -- 头衔
        IC = chars.IC,  -- 图标
    }
end

-- 保存聊天记录
function ChatLogger:SaveRecord(record)
    local date = date("%Y-%m-%d", record.timestamp)
    local hour = date("%H", record.timestamp)

    -- 初始化数据结构
    RPBox_ChatLog[date] = RPBox_ChatLog[date] or {}
    RPBox_ChatLog[date][hour] = RPBox_ChatLog[date][hour] or {}

    -- 添加记录
    table.insert(RPBox_ChatLog[date][hour], record)

    -- 更新同步状态
    RPBox:UpdateSyncState()

    -- 检查记录上限
    self:CheckRecordLimit()
end

-- 检查记录上限
function ChatLogger:CheckRecordLimit()
    local count = RPBox:GetTotalRecordCount()
    if count >= WARN_THRESHOLD and not RPBox_Config.warnedThisSession then
        print("|cFFFFFF00[RPBox]|r 聊天记录已达 " .. count .. " 条")
        print("|cFFFFFF00[RPBox]|r 建议 /reload 后在客户端导出并清理")
        RPBox_Config.warnedThisSession = true
    end
end

-- 目标变化处理（自动白名单）
function ChatLogger:OnTargetChanged()
    if targetTimer then
        targetTimer:Cancel()
        targetTimer = nil
    end

    if not UnitExists("target") or not UnitIsPlayer("target") then
        return
    end

    local unitID = UnitName("target")
    local realm = GetRealmName()
    if unitID then
        unitID = unitID .. "-" .. realm
    end

    if not unitID or RPBox_Config.whitelist[unitID] then
        return
    end

    -- 2秒后自动加入白名单
    targetTimer = C_Timer.NewTimer(2, function()
        if UnitExists("target") then
            local currentTarget = UnitName("target") .. "-" .. realm
            if currentTarget == unitID then
                RPBox_Config.whitelist[unitID] = true
                print("|cFF00FF00[RPBox]|r " .. unitID .. " 已加入记录白名单")
            end
        end
        targetTimer = nil
    end)
end
